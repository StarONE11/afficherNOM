package com.example.train1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity {

    private EditText nom1;
    private Button magie;
    private EditText nom2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nom1 = findViewById(R.id.editTextTextPersonName);
        magie = findViewById(R.id.button);
        nom2 = findViewById(R.id.editTextTextPersonName2);

        magie.setOnClickListener(e ->{
            String joe = nom1.getText().toString();
            nom2.setText(joe);
        });
    }
}